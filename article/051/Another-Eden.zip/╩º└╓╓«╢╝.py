import uiautomator2 as u2
import time
from baseOperator import base
from baseOperator import email
from win10toast import ToastNotifier

d = u2.connect_usb("7c7790ae")  # connect to device


def enter_dungeon():
    print("时间选为古代")
    d.click(241, 181)
    time.sleep(1.2)

    print("选择区域")
    d.click(1896, 972)
    time.sleep(1.2)

    print("选择席尔贝利亚大陆")
    d.click(414, 548)
    time.sleep(1.2)

    print("拖到右上角")
    d.swipe(1434, 397, 596, 708)
    d.swipe(1434, 397, 596, 708)
    d.swipe(1434, 397, 596, 708)
    time.sleep(1.2)

    print("选择失乐之都")
    d.click(704, 384)
    time.sleep(1.2)

    print("选择非常困难")
    d.click(1546, 384)
    time.sleep(1.2)

    if base.is_team_lose(d):
        d.click(1296, 959)
        print("进入副本")
        return True
    else:
        print("未能顺利进入副本")
        return False


def enter_first_floor():
    base.move_right(d, 1.5)
    base.move_up(d, 0.3)
    base.move_right(d, 1.4)
    base.move_up(d, 0.3)
    print("进入副本第 1 层")


# t: 表示第 t 次清理楼层
def clear_the_floor(t):
    if t == 1:
        for j in range(3):
            base.move_left(d, 2)
            base.move_right(d, 2)

        d.click(254, 972)
        time.sleep(1.2)
        d.click(1434, 820)
        time.sleep(1.2)
        d.click(1019, 984)
        time.sleep(1.2)
        d.click(1434, 820)
        time.sleep(1.2)
        base.attack(d)

    for i in range(15):
        base.move_left(d, 2)
        base.attack(d)
        base.move_right(d, 2)
        base.attack(d)
        print("第", i, "次循环")

    # 清怪完成后移动到最右边
    base.move_right(d, 5)


def first_floor():
    base.move_left(d, 2.5)
    base.move_up(d, 0.3)
    base.move_right(d, 1.5)
    base.move_up(d, 0.3)
    base.move_right(d, 1)

    print("开宝箱")
    time.sleep(1.5)
    d.click(1015, 466)
    time.sleep(1.5)
    d.click(1015, 466)
    time.sleep(1.5)

    base.move_left(d, 2.8)
    base.move_down(d, 0.3)
    base.move_left(d, 3.2)
    base.move_down(d, 0.3)
    base.move_left(d, 4)

    print("开宝箱")
    time.sleep(1.5)
    d.click(1183, 462)
    time.sleep(1.5)
    d.click(1183, 462)
    time.sleep(1.5)

    base.move_right(d, 1.4)
    base.move_up(d, 0.3)
    base.move_right(d, 1.5)
    base.move_up(d, 0.3)
    base.move_left(d, 1.5)

    print("进入第 2 层")
    base.move_up(d, 0.3)


def second_floor():
    base.move_left(d, 0.8)
    base.move_up(d, 0.3)
    base.move_right(d, 2)

    print("开宝箱")
    time.sleep(1.5)
    d.click(1650, 388)
    time.sleep(1.5)
    d.click(1650, 388)
    time.sleep(1.5)

    base.move_left(d, 2.5)
    base.move_up(d, 0.3)
    base.move_right(d, 2)
    base.move_up(d, 0.3)

    print("等 fear")
    time.sleep(3)
    for i in range(5):
        print("第", i, "/5 次检测")
        if base.is_fight(d):
            break
        time.sleep(3)
    print("攻击")
    base.attack(d)
    time.sleep(10)
    base.attack(d)
    time.sleep(3)

    base.move_down(d, 0.3)
    base.move_right(d, 7)

    print("开宝箱")
    time.sleep(1.5)
    d.click(1473, 341)
    time.sleep(1.5)
    d.click(1473, 341)
    time.sleep(1.5)

    base.move_left(d, 0.8)
    base.move_down(d, 0.3)
    base.move_left(d, 2.1)
    base.move_down(d, 0.3)
    base.move_right(d, 2.6)

    print("进入第 3 层")
    base.move_up(d, 0.3)


def third_floor():
    base.move_left(d, 0.8)
    base.move_up(d, 0.3)
    base.move_left(d, 1.5)
    base.move_up(d, 0.3)

    print("等 fear")
    time.sleep(3)
    for i in range(10):
        print("第", i, "/10 次检测")
        if base.is_fight(d):
            break
        time.sleep(3)
    print("攻击")
    base.attack(d)
    time.sleep(10)
    base.attack(d)
    time.sleep(3)

    base.move_left(d, 2.2)
    base.move_down(d, 0.3)
    base.move_left(d, 1)

    print("开宝箱")
    time.sleep(1.5)
    d.click(760, 345)
    time.sleep(1.5)
    d.click(760, 345)
    time.sleep(1.5)

    base.move_right(d, 0.5)
    base.move_up(d, 0.3)

    base.move_left(d, 1.5)
    base.move_up(d, 0.3)
    base.move_left(d, 1.5)

    print("开宝箱")
    time.sleep(1.5)
    d.click(786, 315)
    time.sleep(1.5)
    d.click(786, 315)
    time.sleep(1.5)

    base.move_right(d, 0.8)
    base.move_down(d, 0.3)
    base.move_left(d, 1.5)
    base.move_down(d, 0.3)
    base.move_left(d, 3)

    print("进入最后一层")
    d.click(859, 423)


def dungeon_auto():
    if not enter_dungeon():
        return False

    time.sleep(5)

    enter_first_floor()

    time.sleep(3)

    print("开始清怪")
    clear_the_floor(1)
    print("清怪完毕, 去第 2 层")
    first_floor()

    time.sleep(3)

    clear_the_floor(2)
    print("清怪完毕, 去第 3 层")
    second_floor()

    time.sleep(3)

    clear_the_floor(3)
    print("清怪完毕, 去最后一层")
    third_floor()


try:
    start_time = time.time()
    dungeon_auto()
    print("程序已运行", int((time.time() - start_time) / 60), "m",
          int((time.time() - start_time) % 60), "s")
except:
    print("程序运行出现错误")
finally:
    toaster = ToastNotifier()
    toaster.show_toast("程序运行结束",
                       "程序运行结束",
                       duration=5)
