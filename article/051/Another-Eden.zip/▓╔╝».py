import time
import uiautomator2 as u2

d = u2.connect_usb("7c7790ae")  # connect to device

for times in range(3000):
    d.click(1144, 500)
    time.sleep(0.5)
    print(times)


