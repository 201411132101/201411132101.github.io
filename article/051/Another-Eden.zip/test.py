import uiautomator2 as u2
import time
from baseOperator import base
from baseOperator import email
import cv2
import numpy as np
from numpy import random
import math
from win10toast import ToastNotifier

d = u2.connect_usb("7c7790ae")  # connect to device

threshold = 0.02  # 边缘图不同处的百分比
threshold1 = 50  # Canny 边缘算法的下阈值
threshold2 = 150  # Canny 边缘算法的上阈值
# 截图会花费大量时间
image = d.screenshot(format='opencv')[390:460, 860:920]
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
edges = cv2.Canny(gray_image, threshold1, threshold2)
attack_image = cv2.imread('C:\\Users\\bufan\\OneDrive\\script'
                          '\\Another Eden\\pictures\\stage.jpg', cv2.IMREAD_GRAYSCALE)
# cv2.imwrite('test.jpg', edges)
print(np.mean(np.abs(edges / 255. - attack_image / 255.)))
