import uiautomator2 as u2
import time
from baseOperator import base
from baseOperator import email

d = u2.connect_usb("7c7790ae")  # connect to device

# 稻草人 60->80 大概需要 18830000 经验
# 一把回生 186195 经验
Max_number_of_battles = 54  # 最大战斗次数

start_time = time.time()
for times in range(Max_number_of_battles):
    d.click(490, 430)
    time.sleep(1)
    d.click(1287, 967)
    time.sleep(2)

    for i in range(34):
        # print("第", i, "/34 次点击")
        base.attack(d)
        time.sleep(1)

    finish = False
    for i in range(10):
        print("第", i + 1, "检测")
        if base.is_choose(d):
            finish = True
            print("第", times + 1, "次战斗顺利完成, 总耗时",
                  int((time.time() - start_time) / 60), "m",
                  int((time.time() - start_time) % 60), "s")
            break
        else:
            base.attack(d)
            time.sleep(1)

    if not finish:
        break

email.send_email("稻草人已满级")
