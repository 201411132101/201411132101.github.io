import uiautomator2 as u2
import time
from baseOperator import base
from baseOperator import email

d = u2.connect_usb("7c7790ae")  # connect to device

Max_number_of_battles = 3000  # 最大战斗次数
Max_time_of_find_enemy = 30  # 最长寻敌时间
Time_of_find_enemy = 3  # 每次寻敌时间
Time_of_wait = 5  # 战斗动画等待时间
Max_times_of_Round = 5  # 最大战斗轮次


#  n 表示循环运行多少次
# 返回 True 或 False
# True 表示运行顺利, False 表示程序出 bug 了
def simple_fight(n):
    print("开始战斗")
    start_time = time.time()
    for i in range(n):
        base.move_left(d, 2)
        base.attack(d)
        base.move_right(d, 2)
        base.attack(d)
        if (i + 1) % 60 == 0:
            print("程序已运行", int((time.time() - start_time) / 60), "分钟")


simple_fight(5000)
email.send_email("程序运行结束")

