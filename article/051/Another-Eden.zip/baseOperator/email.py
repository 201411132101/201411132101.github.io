import smtplib
from email.mime.text import MIMEText
from email.header import Header


def send_email(content):
    mail_host = "smtp.qq.com"  # 填写邮箱服务器:这个是qq邮箱服务器，直接使用smtp.qq.com
    mail_pass = "nxnktgrtzchobgci"  # 填写在qq邮箱设置中获取的授权码
    sender = '291817591@qq.com'  # 填写邮箱地址
    receivers = ['291817591@qq.com']

    message = MIMEText(content, 'plain', 'utf-8')

    message['From'] = Header("天天快乐", 'utf-8')  # 邮件发送者姓名
    message['To'] = Header("天天快乐", 'utf-8')  # 邮件接收者姓名

    subject = content  # 发送的主题
    message['Subject'] = Header(subject, 'utf-8')

    smtp_obj = smtplib.SMTP_SSL(mail_host, 465)  # 建立smtp连接，qq邮箱必须用ssl边接，因此边接465端口
    smtp_obj.login(sender, mail_pass)  # 登陆
    smtp_obj.sendmail(sender, receivers, message.as_string())  # 发送
    smtp_obj.quit()
