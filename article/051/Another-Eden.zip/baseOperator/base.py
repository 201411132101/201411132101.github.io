import cv2
import numpy as np
import time


# 在此文件中, d始终表示设备


# 移动, t 是移动时间, 单位秒
def move_left(d, t):
    d.touch.down(1800, 550)
    time.sleep(.01)
    d.touch.move(200, 550)  # 模拟移动
    time.sleep(t)
    d.touch.up(200, 550)


def move_right(d, t):
    d.touch.down(200, 550)
    time.sleep(.01)
    d.touch.move(1800, 550)  # 模拟移动
    time.sleep(t)
    d.touch.up(1800, 550)


def move_up(d, t):
    d.touch.down(200, 750)
    time.sleep(.01)
    d.touch.move(200, 250)  # 模拟移动
    time.sleep(t)
    d.touch.up(200, 250)


def move_down(d, t):
    d.touch.down(200, 250)
    time.sleep(.01)
    d.touch.move(200, 750)  # 模拟移动
    time.sleep(t)
    d.touch.up(200, 750)


# 攻击
def attack(d):
    d.click(0.866, 0.86)


# 判断是否进入战斗
def is_fight(d):
    threshold = 0.1  # 边缘图不同处的百分比
    threshold1 = 50  # Canny 边缘算法的下阈值
    threshold2 = 150  # Canny 边缘算法的上阈值

    # 截图会花费大量时间
    image = d.screenshot(format='opencv')[880:972, 1790:1950]
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray_image, threshold1, threshold2)
    attack_image = cv2.imread('C:\\Users\\bufan\\OneDrive\\script'
                              '\\Another Eden\\pictures\\attack.jpg', cv2.IMREAD_GRAYSCALE)
    if np.mean(np.abs(edges / 255. - attack_image / 255.)) < threshold:
        return True
    else:
        return False


# 判断战斗是否结束
def is_battle_finish(d):
    threshold = 0.1  # 边缘图不同处的百分比
    threshold1 = 50  # Canny 边缘算法的下阈值
    threshold2 = 150  # Canny 边缘算法的上阈值

    # 截图会花费大量时间
    image = d.screenshot(format='opencv')[50:110, 30:250]
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray_image, threshold1, threshold2)
    attack_image = cv2.imread('C:\\Users\\bufan\\OneDrive\\script'
                              '\\Another Eden\\pictures\\finish.jpg', cv2.IMREAD_GRAYSCALE)
    if np.mean(np.abs(edges / 255. - attack_image / 255.)) < threshold:
        return True
    else:
        return False


# 判断是否进入回生关卡选择
def is_choose(d):
    threshold = 0.02  # 边缘图不同处的百分比
    threshold1 = 50  # Canny 边缘算法的下阈值
    threshold2 = 150  # Canny 边缘算法的上阈值

    # 截图会花费大量时间
    image = d.screenshot(format='opencv')[390:460, 860:920]
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray_image, threshold1, threshold2)
    attack_image = cv2.imread('C:\\Users\\bufan\\OneDrive\\script'
                              '\\Another Eden\\pictures\\stage.jpg', cv2.IMREAD_GRAYSCALE)
    if np.mean(np.abs(edges / 255. - attack_image / 255.)) < threshold:
        return True
    else:
        return False


# 判断队伍是否为失乐之都
def is_team_lose(d):
    threshold = 0.1  # 边缘图不同处的百分比
    threshold1 = 50  # Canny 边缘算法的下阈值
    threshold2 = 150  # Canny 边缘算法的上阈值

    # 截图会花费大量时间
    image = d.screenshot(format='opencv')[220:280, 345:540]
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray_image, threshold1, threshold2)
    attack_image = cv2.imread('C:\\Users\\bufan\\OneDrive\\script'
                              '\\Another Eden\\pictures\\lose.jpg', cv2.IMREAD_GRAYSCALE)
    if np.mean(np.abs(edges / 255. - attack_image / 255.)) < threshold:
        return True
    else:
        return False


# 判断是否站在路口前
# (sx, sy) 是截图区域左上角
# (ex, ey) 是截图区域右下角
def is_entrance(d, sy, ey, sx, ex):
    threshold = 0.1  # 边缘图不同处的百分比
    threshold1 = 50  # Canny 边缘算法的下阈值
    threshold2 = 150  # Canny 边缘算法的上阈值

    # 截图会花费大量时间
    image = d.screenshot(format='opencv')[sy:ey, sx:ex]
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray_image, threshold1, threshold2)
    attack_image = cv2.imread('C:\\Users\\bufan\\OneDrive\\script'
                              '\\Another Eden\\pictures\\entrance.jpg', cv2.IMREAD_GRAYSCALE)
    if np.mean(np.abs(edges / 255. - attack_image / 255.)) < threshold:
        return True
    else:
        return False
